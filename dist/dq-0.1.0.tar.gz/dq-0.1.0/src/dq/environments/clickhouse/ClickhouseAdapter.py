class ClickhouseAdapter:
    def __init__(self, host, port):
        self.host = host
        self.port = port